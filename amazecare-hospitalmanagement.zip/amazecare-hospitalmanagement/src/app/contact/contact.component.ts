import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact',
  standalone: true,
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css'],
  imports: [CommonModule],  // ✅ ADD THIS LINE
})
export class ContactComponent {
  selectedCity: string = 'All';

  contacts = [
    {
      city: 'Mumbai',
      location: 'MysticFalls-A Care with Love',
      
      area: 'Parel',
      email: 'mumbai@mysticfalls.co.in',
      phone: '+91 75488 10101',
      whatsapp: '+91 70457 09999',
      emergency: '+91 22 6767 0202'
    },
    {
      city: 'Chennai',
      location: 'MysticFalls-Care & Cure',
      area: 'Sholinganallur',
      email: 'chennai@mysticfalls.co.in',
      phone: '+91 79967 89196',
      whatsapp: '+91 96772 61111',
      emergency: '+91 44 4624 2424'
    },
    {
      city: 'Hyderabad',
      location: 'MysticFalls-An AmazeCare',
      area: 'Hyderabad',
      email: 'hyd@mysticfalls.co.in',
      phone: '+91 81210 12345',
      whatsapp: '+91 99880 11223',
      emergency: '+91 40 6767 0202'
    }
  ];

  get filteredContacts() {
    if (this.selectedCity === 'All') {
      return this.contacts;
    }
    return this.contacts.filter(c => c.city === this.selectedCity);
  }

  setCity(city: string) {
    this.selectedCity = city;
  }
}
