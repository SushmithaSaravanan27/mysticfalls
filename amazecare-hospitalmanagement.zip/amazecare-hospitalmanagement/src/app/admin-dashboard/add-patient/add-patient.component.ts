import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AdminService } from 'src/app/shared/services/admin.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-patient',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.css']
})
export class AddPatientComponent {
  patient = {
    fullName: '',
    gender: '',
    dob: '',
    contactNumber: '',
    healthIssue: '',
    username: '',
    email: '',
    password: ''
  };

  message = '';

  constructor(private adminService: AdminService, private router: Router) {}

  addPatient(): void {
    const { fullName, gender, dob, contactNumber, username, password, email } = this.patient;
    if (fullName && gender && dob && contactNumber && username && password && email) {
      this.adminService.addPatient(this.patient).subscribe({
        next: (res: any) => {
          this.message = res?.message || 'Patient added successfully!';
          this.router.navigate(['/admin-dashboard']);
        },
        error: (err) => {
          console.error('❌ Error:', err);
          this.message = '❌ Failed to add patient!';
        }
      });
    } else {
      this.message = '❗ Please fill in all required fields.';
    }
  }
}
