import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../shared/services/admin.service';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manage-patients',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-patients.component.html',
  styleUrls: ['./manage-patients.component.css']
})
export class ManagePatientsComponent implements OnInit {
  patients: any[] = [];
  newPatient = {
    fullName: '',
    gender: '',
    dob: '',
    contactNumber: '',
    healthIssue: ''
  };

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.fetchPatients();
  }

  fetchPatients() {
    this.adminService.getPatients().subscribe((data: any) => {
      this.patients = data;
    });
  }

  addPatient() {
    this.adminService.addPatient(this.newPatient).subscribe(() => {
      alert('Patient added!');
      this.newPatient = {
        fullName: '',
        gender: '',
        dob: '',
        contactNumber: '',
        healthIssue: ''
      };
      this.fetchPatients();
    });
  }

  deletePatient(id: number) {
    if (confirm('Are you sure to delete this patient?')) {
      this.adminService.deletePatient(id).subscribe(() => {
        alert('Patient deleted!');
        this.fetchPatients();
      });
    }
  }
}
