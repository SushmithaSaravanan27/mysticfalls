import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeletePatient } from './delete-patient.component';

describe('DeletePatient', () => {
  let component: DeletePatient;
  let fixture: ComponentFixture<DeletePatient>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DeletePatient]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeletePatient);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
