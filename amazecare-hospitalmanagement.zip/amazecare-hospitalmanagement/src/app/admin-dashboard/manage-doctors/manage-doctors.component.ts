import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../shared/services/admin.service';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-manage-doctors',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manage-doctors.component.html',
  styleUrls: ['./manage-doctors.component.css']
})
export class ManageDoctorsComponent implements OnInit {
  doctors: any[] = [];
  newDoctor = {
    name: '',
    specialty: '',
    experience: 0,
    qualification: '',
    designation: ''
  };

  constructor(private adminService: AdminService) {}

  ngOnInit(): void {
    this.fetchDoctors();
  }

  fetchDoctors() {
    this.adminService.getDoctors().subscribe((data: any) => {
      this.doctors = data;
    });
  }

  addDoctor() {
    this.adminService.addDoctor(this.newDoctor).subscribe(() => {
      alert('Doctor added!');
      this.newDoctor = { name: '', specialty: '', experience: 0, qualification: '', designation: '' };
      this.fetchDoctors();
    });
  }

  deleteDoctor(id: number) {
    if (confirm('Are you sure to delete this doctor?')) {
      this.adminService.deleteDoctor(id).subscribe(() => {
        alert('Doctor deleted!');
        this.fetchDoctors();
      });
    }
  }
}
