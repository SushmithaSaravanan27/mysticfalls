import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from '../../shared/services/admin.service';
import { DoctorService } from '../../shared/services/doctor.service';
import { Doctor } from '../../shared/models/doctor.model';

@Component({
  selector: 'app-delete-doctor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './delete-doctor.component.html',
  styleUrls: ['./delete-doctor.component.css']
})
export class DeleteDoctorComponent implements OnInit {
  doctors: Doctor[] = [];
  doctorId: number = 0;
  message: string = '';
  error: boolean = false;

  constructor(
    private adminService: AdminService,
    private doctorService: DoctorService
  ) {}

  ngOnInit(): void {
    this.doctorService.getAllDoctorIdsAndNames().subscribe({
      next: (data) => {
        this.doctors = data;
      },
      error: () => {
        this.message = '❌ Failed to load doctor list.';
        this.error = true;
      }
    });
  }

  deleteDoctor() {
    if (!this.doctorId || this.doctorId === 0) {
      this.message = 'Please select a Doctor to delete.';
      this.error = true;
      return;
    }

    this.adminService.deleteDoctor(this.doctorId).subscribe({
      next: () => {
        this.message = `Doctor with ID ${this.doctorId} deleted successfully.`;
        this.error = false;
        this.doctorId = 0;
        this.ngOnInit(); // refresh doctor list
      },
      error: (err) => {
        if (err.status === 404) {
          this.message = `Doctor with ID ${this.doctorId} not found.`;
        } else {
          this.message = 'Something went wrong. Try again.';
        }
        this.error = true;
      }
    });
  }
}
