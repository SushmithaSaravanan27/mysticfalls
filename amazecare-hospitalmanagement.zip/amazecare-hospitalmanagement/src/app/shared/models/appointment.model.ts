export interface Appointment {
  id: number;
  doctorId: number;
  patientId: number;
  appointmentDateTime: string;
  symptoms: string;
  status: 'PENDING' | 'COMPLETED' | 'CANCELLED';
}
