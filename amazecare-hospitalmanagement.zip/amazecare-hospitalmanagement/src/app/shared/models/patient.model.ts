export interface Patient {
  id: number;
  fullName: string;
  gender: string;
  age: number;
  contactNumber: string;
  email: string;
}
