export interface Doctor {
  id: number;
  name: string;
  specialty: string;
  designation: string;
  experience: number;
  qualification: string;
    photoUrl: string; 
}
