import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { TokenStorageService } from '../services/token-storage.service';

export const roleGuard = (expectedRole: string): CanActivateFn => {
  return () => {
    const tokenService = inject(TokenStorageService);
    const router = inject(Router);

    const role = tokenService.getRole()?.toUpperCase();

    if (role === expectedRole.toUpperCase()) {
      return true;
    }

    router.navigate(['/login']);
    return false;
  };
};
