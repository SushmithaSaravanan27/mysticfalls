import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PatientService {
  private apiUrl = `${environment.apiUrl}/patient`;

  constructor(private http: HttpClient) {}

  // ✅ Book an appointment
  bookAppointment(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/book`, data);
  }

  // ✅ Get all doctors from patient controller (corrected endpoint)
  getDoctors(): Observable<any> {
    return this.http.get(`${this.apiUrl}/doctors`);
  }

  // ✅ View appointments by patient ID
  getAppointments(patientId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/appointments/${patientId}`);
  }
// ✅ View completed consultations (medical history)
getMedicalHistory(patientId: number): Observable<any> {
  return this.http.get(`${this.apiUrl}/medical-history/${patientId}`);
}


  // ✅ Cancel an appointment by appointment ID
  cancelAppointment(appointmentId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/cancel/${appointmentId}`);
  }
}
