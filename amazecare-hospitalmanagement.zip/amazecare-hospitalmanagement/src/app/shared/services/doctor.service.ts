import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { Doctor } from '../models/doctor.model';

@Injectable({
  providedIn: 'root'
})
export class DoctorService {
  private apiUrl = `${environment.apiUrl}/doctor`;

  constructor(private http: HttpClient) {}

  getAppointments(doctorId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/appointments/${doctorId}`);
  }

  cancelAppointment(appointmentId: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/cancel/${appointmentId}`, {});
  }

  addPrescription(data: any): Observable<string> {
    return this.http.post(`${this.apiUrl}/prescribe`, data, { responseType: 'text' });
  }

  getCompletedConsultations(doctorId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/completed-consultations/${doctorId}`);
  }

  getAllDoctors(): Observable<Doctor[]> {
    return this.http.get<Doctor[]>(`${this.apiUrl}/all`);
  }

  getAllSpecialties(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiUrl}/specialties`);
  }
  getAllDoctorIdsAndNames(): Observable<Doctor[]> {
  return this.http.get<Doctor[]>(`${this.apiUrl}/id-name`);
}

}
