import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { TokenStorageService } from 'src/app/shared/services/token-storage.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  username: string | null = null;
  role: string | null = null;

  showDropdown = false; // ✅ Controls department dropdown visibility

  constructor(
    private tokenStorageService: TokenStorageService,
    private router: Router
  ) {
    this.username = this.tokenStorageService.getUsername();
    this.role = this.tokenStorageService.getRole();
  }

  getDashboardRoute(): string {
    switch (this.role) {
      case 'ADMIN': return '/admin-dashboard';
      case 'DOCTOR': return '/doctor-dashboard';
      case 'PATIENT': return '/patient-dashboard';
      default: return '/login';
    }
  }

  logout(): void {
    this.tokenStorageService.signOut();
    window.location.href = '/login';
  }

  // ✅ Navigate to department with query param
  loadDepartment(department: string): void {
    this.router.navigate(['/departments'], { queryParams: { name: department } });
  }
}
