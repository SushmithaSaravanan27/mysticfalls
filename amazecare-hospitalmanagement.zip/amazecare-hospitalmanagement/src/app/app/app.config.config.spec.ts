import { AppConfig } from './app.configconfig';

describe('AppConfig', () => {
  it('should create an instance', () => {
    expect(new AppConfig()).toBeTruthy();
  });
});
