import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DoctorService } from '../../shared/services/doctor.service';

@Component({
  selector: 'app-add-prescription',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './add-prescription.component.html',
  styleUrls: ['./add-prescription.component.css']
})
export class AddPrescriptionComponent {
  prescription = {
    appointmentId: 0,
    symptoms: '',
    diagnosis: '',
    treatmentPlan: '',
    recommendedTests: '',
    prescribedMedicine: ''
  };

  successMessage = '';
  errorMessage = '';

  constructor(private doctorService: DoctorService) {}

  submitPrescription() {
    if (
      this.prescription.appointmentId &&
      this.prescription.symptoms &&
      this.prescription.diagnosis &&
      this.prescription.treatmentPlan &&
      this.prescription.prescribedMedicine
    ) {
      this.doctorService.addPrescription(this.prescription).subscribe({
        next: (res) => {
          this.successMessage = 'Prescription submitted successfully.';
          this.errorMessage = '';
          this.prescription = {
            appointmentId: 0,
            symptoms: '',
            diagnosis: '',
            treatmentPlan: '',
            recommendedTests: '',
            prescribedMedicine: ''
          };
        },
        error: () => {
          this.errorMessage = 'Failed to submit prescription.';
          this.successMessage = '';
        }
      });
    } else {
      this.errorMessage = 'Please fill all required fields.';
      this.successMessage = '';
    }
  }
}
