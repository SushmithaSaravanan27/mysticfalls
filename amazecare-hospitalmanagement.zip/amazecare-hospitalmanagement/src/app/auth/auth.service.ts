import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, tap } from 'rxjs';
import { TokenStorageService } from '../shared/services/token-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`;

  constructor(
    private http: HttpClient,
    private tokenStorage: TokenStorageService
  ) {}

  login(data: { username: string; password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, data).pipe(
      tap((response: any) => {
        this.tokenStorage.saveToken(response.token);
        this.tokenStorage.saveUsername(response.username);
        this.tokenStorage.saveRole(response.role);
        this.tokenStorage.saveUser(response);
        this.tokenStorage.saveUserId(response.id);

        if (response.patientId) {
          localStorage.setItem('patientId', response.patientId.toString());
        }

        if (response.doctorId) {
          localStorage.setItem('doctorId', response.doctorId.toString());
        }
      })
    );
  }

  register(data: { username: string; email: string; password: string; role: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, data);
  }

  forgetPassword(username: string, newPassword: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/forget-password`, { username, newPassword });
  }
}
