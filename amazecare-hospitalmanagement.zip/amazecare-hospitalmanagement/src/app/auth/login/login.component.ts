import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { AuthService } from '../auth.service';
import { TokenStorageService } from '../../shared/services/token-storage.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, CommonModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private authService: AuthService,
    private tokenStorage: TokenStorageService,
    private router: Router
  ) {}

  login(): void {
    if (!this.username || !this.password) {
      this.errorMessage = 'All fields are required.';
      this.successMessage = '';
      return;
    }

    this.authService.login({ username: this.username, password: this.password }).subscribe({
      next: (res: any) => {
        console.log(' Login success:', res);

        // ✅ Save user/session data
        this.tokenStorage.saveToken(res.token);
        this.tokenStorage.saveUsername(res.username);
        this.tokenStorage.saveRole(res.role);
        this.tokenStorage.saveUserId(res.id);
        this.tokenStorage.saveUser(res); // optional: full user object

        const role = res.role?.toUpperCase();

        // ✅ Save role-specific ID
        if (role === 'PATIENT' && res.patientId) {
          localStorage.setItem('amazecare-patient-id', res.patientId.toString());
        }
        if (role === 'DOCTOR' && res.doctorId) {
          localStorage.setItem('amazecare-doctor-id', res.doctorId.toString());
        }

        // ✅ Display success message
        this.successMessage = res.message || 'User logged in successfully.';
        this.errorMessage = '';

        // ✅ Navigate after short delay
        setTimeout(() => {
          if (role === 'ADMIN') {
            this.router.navigate(['/admin-dashboard']);
          } else if (role === 'DOCTOR') {
            this.router.navigate(['/doctor-dashboard/home']);
          } else if (role === 'PATIENT') {
            this.router.navigate(['/patient-dashboard']);
          } else {
            console.error('Unknown role:', role);
            this.errorMessage = 'Unknown user role. Cannot navigate.';
          }
        }, 1000); // 1 second delay to let user see success
      },
      error: (err) => {
        console.error('Login error:', err);

        if (err?.error?.message) {
          this.errorMessage = err.error.message;
        } else if (typeof err.error === 'string') {
          this.errorMessage = err.error;
        } else {
          this.errorMessage = 'Login failed. Please try again.';
        }

        this.successMessage = '';
      }
    });
  }
}
