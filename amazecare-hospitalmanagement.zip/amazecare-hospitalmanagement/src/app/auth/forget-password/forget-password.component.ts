import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-forget-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})
export class ForgetPasswordComponent {
  username: string = '';
  newPassword: string = '';
  message: string = '';
  errorMessage: string = '';

  constructor(private authService: AuthService, private router: Router) {}

  submit(): void {
    if (!this.username || !this.newPassword) {
      this.errorMessage = 'All fields are required.';
      this.message = '';
      return;
    }

    this.authService.forgetPassword(this.username, this.newPassword).subscribe({
      next: (res) => {
        this.message = res.message || 'Password reset successful!';
        this.errorMessage = '';
        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 1500);
      },
      error: (err) => {
        console.error('Forget password error:', err);
        this.errorMessage = err?.error?.message || 'Failed to reset password.';
        this.message = '';
      }
    });
  }
}
