import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GeneralSurgery } from './general-surgery';

describe('GeneralSurgery', () => {
  let component: GeneralSurgery;
  let fixture: ComponentFixture<GeneralSurgery>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [GeneralSurgery]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GeneralSurgery);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
