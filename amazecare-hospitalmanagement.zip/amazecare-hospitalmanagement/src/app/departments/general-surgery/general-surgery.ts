// src/app/departments/general-surgery/general-surgery.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-generalsurgery',
  templateUrl: './general-surgery.html',
  styleUrls: ['./general-surgery.css'],
  standalone: true,
  imports: [CommonModule] // ✅ Import CommonModule to use *ngIf
})
export class GeneralSurgery {
  showMore: boolean = false;

  toggleReadMore(): void {
    this.showMore = !this.showMore;
  }
}
