import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-departments',
  standalone: true,
  templateUrl: './departments.component.html',
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent {
  constructor(private router: Router) {}

  loadDepartment(department: string) {
    switch (department) {
      case 'General Surgery':
        this.router.navigate(['/generalsurgery']);
        break;
      case 'Organ Transplant':
        this.router.navigate(['/organtransplant']);
        break;
      case 'Infertility Medicine':
        this.router.navigate(['/infertilitymedicine']);
        break;
      case 'Neurology':
        this.router.navigate(['/neurology']);
        break;
    
      case 'Radiology':
        this.router.navigate(['/radiology']);
        break;
      default:
        this.router.navigate(['/departments']);
        break;
    }
  }
}
