import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-organtransplant',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './organ-transplant.html',
  styleUrls: ['./organ-transplant.css']
})
export class OrganTransplant {
  showMore: boolean = false;

  toggleReadMore(): void {
    this.showMore = !this.showMore;
  }
}
