import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrganTransplant } from './organ-transplant';

describe('OrganTransplant', () => {
  let component: OrganTransplant;
  let fixture: ComponentFixture<OrganTransplant>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrganTransplant]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrganTransplant);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
