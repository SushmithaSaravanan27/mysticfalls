import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-radiology',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './radiology.html',
  styleUrls: ['./radiology.css']
})
export class Radiology {
  showMore: boolean = false;

  toggleReadMore(): void {
    this.showMore = !this.showMore;
  }
}
