import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-neurology',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './neurology.html',
  styleUrls: ['./neurology.css']
})
export class Neurology {
  showMore: boolean = false;

  toggleReadMore(): void {
    this.showMore = !this.showMore;
  }
}
