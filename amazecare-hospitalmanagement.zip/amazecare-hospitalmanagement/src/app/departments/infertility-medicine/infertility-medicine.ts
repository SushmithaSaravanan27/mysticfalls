import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-infertility-medicine',
  templateUrl: './infertility-medicine.html',
  styleUrls: ['./infertility-medicine.css'],
  standalone: true,
  imports: [CommonModule]
})
export class InfertilityMedicine {
  showMore: boolean = false;

  toggleReadMore(): void {
    this.showMore = !this.showMore;
  }
}
