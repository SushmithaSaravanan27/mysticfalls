import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AdminService } from 'src/app/shared/services/admin.service';

@Component({
  standalone: true,
  selector: 'app-cancel-appointment',
  templateUrl: './cancel-appointment.component.html',
  styleUrls: ['./cancel-appointment.component.css'],
  imports: [CommonModule, FormsModule]
})
export class CancelAppointmentComponent {
  appointmentId: number | null = null;
  message: string = '';
  error: string = '';

  constructor(private adminService: AdminService) {}

  cancelAppointment(): void {
    if (!this.appointmentId) {
      this.error = 'Please enter a valid Appointment ID';
      this.message = '';
      return;
    }

    this.adminService.cancelAppointment(this.appointmentId).subscribe({
      next: (res) => {
        this.message = `✅ Appointment ID ${this.appointmentId} cancelled successfully.`;
        this.error = '';
        this.appointmentId = null;
      },
      error: (err) => {
        this.error = err?.error?.message || '❌ Appointment not found or already cancelled.';
        this.message = '';
      }
    });
  }
}
