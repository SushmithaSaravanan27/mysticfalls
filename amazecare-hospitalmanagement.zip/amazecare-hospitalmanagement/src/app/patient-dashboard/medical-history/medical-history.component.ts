import { Component, OnInit } from '@angular/core';
import { PatientService } from 'src/app/shared/services/patient.service';
import { TokenStorageService } from 'src/app/shared/services/token-storage.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-medical-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './medical-history.component.html',
  styleUrls: ['./medical-history.component.css']
})
export class MedicalHistoryComponent implements OnInit {
  patientId!: number;
  completedAppointments: any[] = [];

  constructor(
    private patientService: PatientService,
    private tokenService: TokenStorageService
  ) {}

  ngOnInit(): void {
    this.patientId = this.tokenService.getPatientId() || 0;

    if (this.patientId) {
      this.patientService.getMedicalHistory(this.patientId).subscribe({
        next: (data: any[]) => {
          this.completedAppointments = data;
        },
        error: (err) => {
          console.error('Error fetching medical history', err);
        }
      });
    } else {
      console.error('Invalid or missing patientId in localStorage');
    }
  }
}
