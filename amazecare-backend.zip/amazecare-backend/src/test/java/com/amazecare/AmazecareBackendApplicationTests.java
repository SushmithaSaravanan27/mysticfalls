package com.amazecare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazecareBackendApplicationTests {

	@Test
	void contextLoads() {
		System.out.println(" Application context loaded successfully!");
	}

}
