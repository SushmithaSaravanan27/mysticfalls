package com.amazecare.dto;

import lombok.Data;

@Data
public class PatientDTO {
    private String fullName;
    private String gender;
    private String dob;
    private String contactNumber;
    private String healthIssue;
    private String username;
    private String password;
    private Long id;
    private String name;
    private String email;


}
